import { decodeFunctionResult, encodeFunctionData, isAddress, isHex, parseAbi, toHex, type Abi, type Address, type Hex } from "viem";
import { LifecyclePlanningError, type LifecycleBlock, type LifecycleDiagnosticEvent, type LifecycleDiagnosticListener, type LifecycleDiagnosticStage, type LifecycleLimitContext, type LifecycleLimitSource, type LifecycleLimits, type LifecycleRpcClient, type LifecycleSessionCache, type LifecycleTransaction, type ResolvedLifecycleLimits } from "./types.js";
import { lifecycleRegistryAbi } from "./abi.js";
import type { ProfileTopologyV1 } from "./schema.js";

const lifecycleReadConcurrency = 8;
const diagnosticRpcMethods: Record<string, true> = {
  eth_chainId: true, eth_getBlockByNumber: true, eth_getBlockByHash: true, eth_getCode: true,
  eth_getBalance: true, eth_call: true, eth_estimateGas: true, eth_gasPrice: true,
  eth_simulateV1: true, eth_getTransactionCount: true, eth_getTransactionReceipt: true, eth_getTransactionByHash: true,
};

type SessionReadGroup = {
  source: LifecycleRpcClient;
  request: LifecycleRpcClient["request"];
  chainId?: bigint;
  block: Readonly<Pick<LifecycleBlock, "number" | "hash">>;
  values: Map<string, Hex>;
};

/** Private wire observations; callers can inspect the pin or discard it, never install values. */
class SessionLifecycleCache implements LifecycleSessionCache {
  #group?: SessionReadGroup;

  get block(): LifecycleSessionCache["block"] { return this.#group?.block; }

  invalidate(): void {
    this.#group?.values.clear();
    this.#group = undefined;
  }

  pin(source: LifecycleRpcClient, block: LifecycleBlock, chainId?: bigint): SessionReadGroup {
    const group = this.#group;
    if (group !== undefined && group.source === source && group.request === source.request &&
      group.block.number === block.number && group.block.hash.toLowerCase() === block.hash.toLowerCase() &&
      (chainId === undefined || group.chainId === undefined || group.chainId === chainId)) {
      if (chainId !== undefined) group.chainId = chainId;
      return group;
    }
    this.invalidate();
    return this.#group = {
      source, request: source.request, chainId,
      block: Object.freeze({ number: block.number, hash: block.hash }),
      values: new Map(),
    };
  }

  isCurrent(group: SessionReadGroup, block: LifecycleBlock): boolean {
    return this.#group === group && group.request === group.source.request &&
      group.block.number === block.number && group.block.hash.toLowerCase() === block.hash.toLowerCase();
  }

  observeChain(group: SessionReadGroup, chainId: bigint): void {
    if (this.#group !== group) return;
    if (group.chainId !== undefined && group.chainId !== chainId) this.invalidate();
    else group.chainId = chainId;
  }
}

/** Opt in per caller/session; there is no global or transport-owned lifecycle cache. */
export function createLifecycleSessionCache(): LifecycleSessionCache {
  return new SessionLifecycleCache();
}

/** Owns only one invocation's immutable RPC observations, never live checks or writes. */
class InvocationLifecycleClient implements LifecycleRpcClient {
  private readonly reads = new Map<string, Promise<unknown>>();
  private readonly active = new Set<Promise<void>>();
  private closed = false;
  private readonly concurrency: number;
  private diagnosticSequence = 0;
  private chainId?: Promise<bigint>;
  private readonly limitObservations = new Map<LifecycleLimitSource | undefined, Map<string, Promise<LifecycleLimitObservation>>>();
  private readonly session?: SessionLifecycleCache;
  private sessionGroup?: SessionReadGroup;
  private observedChainId?: bigint;
  private sessionHits = 0;
  private sessionMisses = 0;
  private sessionReuses = 0;
  constructor(readonly source: LifecycleRpcClient) {
    this.concurrency = source.supportsReadBatching === true ? lifecycleReadConcurrency : 1;
    if (source.sessionCache !== undefined) {
      if (!(source.sessionCache instanceof SessionLifecycleCache)) throw new LifecyclePlanningError("INVALID_SESSION_CACHE", "Lifecycle session cache must be created by createLifecycleSessionCache");
      this.session = source.sessionCache;
      if (source.onDiagnostic !== undefined) emitLifecycleDiagnostic(source.onDiagnostic, { stage: "session-cache", phase: "start" });
    }
  }

  async request(args: { method: string; params?: readonly unknown[] }): Promise<unknown> {
    this.assertOpen();
    const result = await this.source.request(args);
    this.assertOpen();
    return result;
  }

  assertOpen(): void {
    if (this.closed) throw new LifecyclePlanningError("READ_SCOPE_CLOSED", "Lifecycle read invocation has already settled");
  }

  async run(method: string, params: readonly unknown[]): Promise<unknown> {
    this.assertOpen();
    const listener = this.source.onDiagnostic;
    const observedMethod = listener === undefined ? undefined : diagnosticRpcMethods[method] === true ? method : "other";
    const queuedAt = listener === undefined ? 0 : performance.now();
    const requestId = listener === undefined ? 0 : ++this.diagnosticSequence;
    if (listener !== undefined) emitLifecycleDiagnostic(listener, { stage: "rpc", phase: "queued", requestId, method: observedMethod });
    while (this.active.size >= this.concurrency) await Promise.race(this.active);
    this.assertOpen();
    const started = listener === undefined ? 0 : performance.now();
    if (listener !== undefined) emitLifecycleDiagnostic(listener, { stage: "rpc", phase: "start", requestId, method: observedMethod, queueMs: started - queuedAt });
    const pending = this.request({ method, params });
    const settled = pending.then(
      () => { this.active.delete(settled); },
      () => { this.active.delete(settled); },
    );
    this.active.add(settled);
    try {
      const result = await pending;
      if (listener !== undefined) emitLifecycleDiagnostic(listener, { stage: "rpc", phase: "success", requestId, method: observedMethod, durationMs: performance.now() - started });
      if (this.session !== undefined && method === "eth_chainId") {
        this.observedChainId = rpcQuantity(result, "chain ID");
        if (this.sessionGroup !== undefined) this.session.observeChain(this.sessionGroup, this.observedChainId);
      }
      return result;
    } catch (error) {
      if (listener !== undefined) emitLifecycleDiagnostic(listener, { stage: "rpc", phase: "failure", requestId, method: observedMethod, durationMs: performance.now() - started });
      throw error;
    }
  }

  observeBlock(block: LifecycleBlock, latest: boolean): void {
    if (this.session === undefined) return;
    this.assertOpen();
    if (latest) {
      this.sessionGroup = this.session.pin(this.source, block, this.observedChainId);
    } else if (this.sessionGroup?.block.number === block.number && this.sessionGroup.block.hash.toLowerCase() !== block.hash.toLowerCase()) {
      this.invalidateSession();
    }
  }

  invalidateSession(): void {
    this.session?.invalidate();
    this.sessionGroup = undefined;
  }

  observeChainId(): Promise<bigint> {
    this.assertOpen();
    return this.chainId ??= this.run("eth_chainId", []).then((value) => rpcQuantity(value, "chain ID"));
  }

  observeLimits(context: LifecycleLimitContext, source?: LifecycleLimitSource): Promise<LifecycleLimitObservation> {
    this.assertOpen();
    // A caller callback is live policy, not an immutable pinned observation.
    // Its current result must validate provenance; native fixed-state reads still reuse their wire cache.
    if (typeof source === "function") return resolveLifecycleLimitsFresh(context, source).then((result) => {
      this.assertOpen();
      result.assertCurrent();
      return result;
    });
    const key = JSON.stringify([context.chainId.toString(), context.account.toLowerCase(), context.orchestrator.toLowerCase(), context.block.number.toString(), context.block.hash.toLowerCase(), context.block.timestamp.toString(), context.block.gasLimit.toString(), context.block.baseFeePerGas?.toString()]);
    let byContext = this.limitObservations.get(source);
    if (byContext === undefined) { byContext = new Map(); this.limitObservations.set(source, byContext); }
    const contexts = byContext;
    let observation = byContext.get(key);
    if (observation === undefined) {
      observation = resolveLifecycleLimitsFresh(context, source);
      byContext.set(key, observation);
      const owned = observation;
      void owned.catch(() => { if (contexts.get(key) === owned) contexts.delete(key); });
    }
    return observation.then((result) => { this.assertOpen(); result.assertCurrent(); return result; });
  }

  read(method: string, params: readonly unknown[], block: LifecycleBlock, staticRead = false): Promise<unknown> {
    this.assertOpen();
    // Source identity is this scope's original client. The complete wire call includes
    // caller, value, gas and any other call fields; no selector-only/ABI-name aliasing.
    const key = JSON.stringify([block.number.toString(), block.hash.toLowerCase(), method, params]);
    const existing = this.reads.get(key);
    if (existing !== undefined) {
      if (staticRead && this.session !== undefined) this.sessionReuses += 1;
      const listener = this.source.onDiagnostic;
      if (listener !== undefined) emitLifecycleDiagnostic(listener, { stage: "rpc", phase: "reuse", method: diagnosticRpcMethods[method] === true ? method : "other" });
      return existing;
    }
    const group = staticRead && this.observedChainId !== undefined && this.sessionGroup !== undefined &&
      this.session?.isCurrent(this.sessionGroup, block) ? this.sessionGroup : undefined;
    const cached = group?.values.get(key);
    let pending: Promise<unknown>;
    if (cached !== undefined) {
      this.sessionHits += 1;
      pending = Promise.resolve(cached);
    } else {
      if (staticRead && this.session !== undefined) this.sessionMisses += 1;
      pending = this.run(method, params);
      if (group !== undefined) pending = pending.then((value) => {
        // Never share in-flight work or install late results after invalidation/closure.
        // Only wire hex is retained, so public decoded DTOs cannot mutate authority.
        if (!this.closed && this.session?.isCurrent(group, block) && typeof value === "string" && isHex(value)) group.values.set(key, value);
        return value;
      });
    }
    this.reads.set(key, pending);
    void pending.catch(() => { if (this.reads.get(key) === pending) this.reads.delete(key); });
    return pending;
  }

  close(success: boolean): void {
    this.closed = true;
    this.reads.clear();
    this.chainId = undefined;
    this.limitObservations.clear();
    const listener = this.source.onDiagnostic;
    if (this.session !== undefined && listener !== undefined) emitLifecycleDiagnostic(listener, {
      stage: "session-cache", phase: success ? "success" : "failure",
      hits: this.sessionHits, misses: this.sessionMisses, reuses: this.sessionReuses,
    });
  }
}

/** Internal callers join the same invocation; only explicit static reads opt in to a session. */
export async function withLifecycleReadClient<T>(source: LifecycleRpcClient, work: (client: LifecycleRpcClient) => Promise<T>): Promise<T> {
  if (source instanceof InvocationLifecycleClient) return work(source);
  const client = new InvocationLifecycleClient(source);
  let success = false;
  try {
    const result = await work(client);
    success = true;
    return result;
  } finally { client.close(success); }
}

export function lifecycleSourceClient(client: LifecycleRpcClient): LifecycleRpcClient {
  return client instanceof InvocationLifecycleClient ? client.source : client;
}

/** Internal continuations cannot retain proof after their read owner settles. */
export function assertLifecycleReadClientOpen(client: LifecycleRpcClient): boolean {
  if (!(client instanceof InvocationLifecycleClient)) return false;
  client.assertOpen();
  return true;
}

function emitLifecycleDiagnostic(listener: LifecycleDiagnosticListener, event: LifecycleDiagnosticEvent): void {
  try {
    const pending = listener(event);
    if (pending !== undefined) void pending.catch(() => {});
  } catch { /* Observers cannot change financial behavior. */ }
}

/** No clock, event allocation or extra promise when diagnostics are disabled. */
export function lifecycleStage<T>(client: LifecycleRpcClient, stage: LifecycleDiagnosticStage, work: () => Promise<T>): Promise<T> {
  const listener = lifecycleSourceClient(client).onDiagnostic;
  return listener === undefined ? work() : observedLifecycleStage(listener, stage, work);
}

async function observedLifecycleStage<T>(listener: LifecycleDiagnosticListener, stage: LifecycleDiagnosticStage, work: () => Promise<T>): Promise<T> {
  const started = performance.now();
  emitLifecycleDiagnostic(listener, { stage, phase: "start" });
  try {
    const result = await work();
    emitLifecycleDiagnostic(listener, { stage, phase: "success", durationMs: performance.now() - started });
    return result;
  } catch (error) {
    emitLifecycleDiagnostic(listener, { stage, phase: "failure", durationMs: performance.now() - started });
    throw error;
  }
}

/** Only explicitly pinned fixed-state reads may participate in invocation reuse. */
export async function lifecyclePinnedRpc(client: LifecycleRpcClient, method: "eth_call" | "eth_getCode" | "eth_getBalance", params: readonly unknown[], block: LifecycleBlock, staticRead = false): Promise<unknown> {
  if (params.length !== 2 || params[1] !== toHex(block.number)) throw new LifecyclePlanningError("INVALID_READ_CONTEXT", "Reusable lifecycle reads require the exact pinned block and no state overrides");
  return client instanceof InvocationLifecycleClient ? client.read(method, params, block, staticRead && method !== "eth_getBalance") : lifecycleRpc(client, method, params);
}

/** Explicit SDK-owned static class only; balances and execution calls never use this path. */
export function lifecycleStaticRpc(client: LifecycleRpcClient, method: "eth_call" | "eth_getCode", params: readonly unknown[], block: LifecycleBlock): Promise<unknown> {
  return lifecyclePinnedRpc(client, method, params, block, true);
}

export async function lifecycleRpc(client: LifecycleRpcClient, method: string, params: readonly unknown[] = []): Promise<unknown> {
  return client instanceof InvocationLifecycleClient ? client.run(method, params) : client.request({ method, params });
}
/** One invocation's observed identity. End-of-operation and submission checks
 * deliberately use uncached eth_chainId so a switched provider cannot retain proof. */
export function readLifecycleChainId(client: LifecycleRpcClient): Promise<bigint> {
  return client instanceof InvocationLifecycleClient
    ? client.observeChainId()
    : lifecycleRpc(client, "eth_chainId").then((value) => rpcQuantity(value, "chain ID"));
}
export function rpcObject(value: unknown, label: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", `${label} must be an object`);
  // The object guard establishes the RPC record boundary; fields remain untrusted unknowns.
  const record = value as Record<string, unknown>;
  return record;
}
export function rpcHex(value: unknown, label: string): Hex {
  if (typeof value !== "string" || !isHex(value)) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", `${label} must be hex`);
  return value;
}
export function rpcQuantity(value: unknown, label: string): bigint {
  const hex = rpcHex(value, label);
  if (!/^0x[0-9a-fA-F]+$/.test(hex)) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", `${label} must be a quantity`);
  return BigInt(hex);
}

/** Public refusal details contain only fixed text and numeric RPC/HTTP codes, never provider messages. */
export function lifecycleFailureReason(failure: unknown): string {
  for (let depth = 0; depth < 8 && failure !== null && typeof failure === "object"; depth += 1) {
    const error = failure as { code?: unknown; status?: unknown; statusCode?: unknown; cause?: unknown };
    const status = error.status ?? error.statusCode;
    if (typeof status === "number" && Number.isSafeInteger(status) && status >= 400 && status <= 599) return `HTTP read failed (status ${status})`;
    if (typeof error.code === "number" && Number.isSafeInteger(error.code)) return `RPC request failed (code ${error.code})`;
    if (failure instanceof LifecyclePlanningError) return "Lifecycle planning guard rejected the request";
    failure = error.cause;
  }
  return "Read or execution proof failed";
}
export async function readLifecycleBlock(client: LifecycleRpcClient, tag: Hex | "latest" = "latest"): Promise<LifecycleBlock> {
  const value = rpcObject(await lifecycleRpc(client, "eth_getBlockByNumber", [tag, false]), "block");
  const hash = rpcHex(value.hash, "block hash");
  if (hash.length !== 66) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", "Block hash must have 32 bytes");
  const block = {
    number: rpcQuantity(value.number, "block number"), hash,
    timestamp: rpcQuantity(value.timestamp, "block timestamp"), gasLimit: rpcQuantity(value.gasLimit, "block gas limit"),
    baseFeePerGas: value.baseFeePerGas === undefined || value.baseFeePerGas === null ? undefined : rpcQuantity(value.baseFeePerGas, "base fee"),
  };
  if (client instanceof InvocationLifecycleClient) client.observeBlock(block, tag === "latest");
  return block;
}
export async function assertLifecycleBlock(client: LifecycleRpcClient, block: LifecycleBlock, expectedChainId?: bigint): Promise<void> {
  const [chainId, current] = await Promise.all([
    expectedChainId === undefined ? undefined : lifecycleRpc(client, "eth_chainId"),
    readLifecycleBlock(client, toHex(block.number)),
  ]);
  if (expectedChainId !== undefined && rpcQuantity(chainId, "chain ID") !== expectedChainId) {
    if (client instanceof InvocationLifecycleClient) client.invalidateSession();
    throw new LifecyclePlanningError("CHAIN_MISMATCH", "Source RPC chain changed during the pinned operation");
  }
  if (current.hash.toLowerCase() !== block.hash.toLowerCase()) {
    if (client instanceof InvocationLifecycleClient) client.invalidateSession();
    throw new LifecyclePlanningError("STATE_REORGED", "Pinned launch state changed during the operation; read canonical progress again");
  }
}
export async function readLifecycleContract<T>(client: LifecycleRpcClient, to: Address, abi: Abi, functionName: string, args: readonly unknown[], block: LifecycleBlock, from?: Address, staticRead = false): Promise<T> {
  const data = encodeFunctionData({ abi, functionName, args });
  const request = [{ to, from, data }, toHex(block.number)];
  const getter = abi.some((item) => item.type === "function" && item.name === functionName && (item.stateMutability === "view" || item.stateMutability === "pure"));
  const result = rpcHex(await (getter && functionName !== "readLaunchProgress"
    ? staticRead ? lifecycleStaticRpc(client, "eth_call", request, block) : lifecyclePinnedRpc(client, "eth_call", request, block)
    : lifecycleRpc(client, "eth_call", request)), functionName);
  // ABI decoding validates scalar widths and tuple layout; T names that exact frozen ABI result.
  const decoded = decodeFunctionResult({ abi, functionName, data: result }) as T;
  return decoded;
}

/** Certification/configuration getters, explicitly selected by their SDK callsite. */
export function readLifecycleStaticContract<T>(client: LifecycleRpcClient, to: Address, abi: Abi, functionName: string, args: readonly unknown[], block: LifecycleBlock, from?: Address): Promise<T> {
  return readLifecycleContract<T>(client, to, abi, functionName, args, block, from, true);
}

/** A reviewed registry must supply topology; missing selectors never certify a profile. */
export async function readLifecycleProfileTopology(client: LifecycleRpcClient, registry: Address, profileId: Hex, block: LifecycleBlock): Promise<ProfileTopologyV1> {
  const topology = await readLifecycleStaticContract<{ hookTopology: number; configVersion: number; hookDeployer: Address; hookCreationCodeHash: Hex }>(client, registry, lifecycleRegistryAbi, "profileTopology", [profileId], block);
  if (topology.hookTopology !== 0 && topology.hookTopology !== 1 && topology.hookTopology !== 2) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", "Registry returned an unsupported hook topology");
  return { ...topology, hookTopology: topology.hookTopology };
}
export const nitroArbSys = "0x0000000000000000000000000000000000000064";
export const nitroGasInfo = "0x000000000000000000000000000000000000006c";
export const nitroNodeInterface = "0x00000000000000000000000000000000000000c8";
export const nitroArbSysAbi = parseAbi(["function arbOSVersion() view returns (uint256)"]);
export const nitroGasInfoAbi = parseAbi(["function getMaxTxGasLimit() view returns (uint256)", "function getMaxBlockGasLimit() view returns (uint64)"]);
const nitroNodeInterfaceAbi = parseAbi(["function gasEstimateL1Component(address to, bool contractCreation, bytes data) payable returns (uint64 gasEstimateForL1, uint256 baseFee, uint256 l1BaseFeeEstimate)"]);
const maxUint64 = (1n << 64n) - 1n;

/** A poster quote is an envelope budget, never an execution/compute proof. */
export async function readNitroPosterGas(transaction: LifecycleTransaction, context: LifecycleLimitContext): Promise<{ posterGas: bigint; baseFee: bigint; l1BaseFeeEstimate: bigint }> {
  const data = encodeFunctionData({ abi: nitroNodeInterfaceAbi, functionName: "gasEstimateL1Component", args: [transaction.to, false, transaction.data] });
  const result = rpcHex(await lifecycleStaticRpc(context.client, "eth_call", [{ from: transaction.from, to: nitroNodeInterface, data, value: toHex(transaction.value) }, toHex(context.block.number)], context.block), "Nitro poster estimate");
  if (result.length !== 194) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", "Nitro poster estimate must contain exactly three ABI words");
  const [posterGas, baseFee, l1BaseFeeEstimate] = decodeFunctionResult({ abi: nitroNodeInterfaceAbi, functionName: "gasEstimateL1Component", data: result });
  if (posterGas < 0n || posterGas > maxUint64 || baseFee <= 0n || l1BaseFeeEstimate < 0n) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", "Nitro poster estimate has invalid gas or fee values");
  return { posterGas, baseFee, l1BaseFeeEstimate };
}

async function readNitroScalar(context: LifecycleLimitContext, to: Address, abi: Abi, functionName: string): Promise<bigint> {
  const data = encodeFunctionData({ abi, functionName });
  const result = rpcHex(await lifecycleStaticRpc(context.client, "eth_call", [{ to, data }, toHex(context.block.number)], context.block), functionName);
  if (result.length !== 66) throw new LifecyclePlanningError("INVALID_RPC_RESPONSE", `${functionName} must return exactly one ABI word`);
  return decodeFunctionResult({ abi, functionName, data: result }) as bigint;
}

export type LifecycleLimitObservation = {
  limits: ResolvedLifecycleLimits;
  configuration: LifecycleLimits;
  assertCurrent: () => void;
};

/** Reuse only SDK-owned, pinned observations inside the still-open invocation.
 * Caller-supplied policies remain checked for mutation on every consumption. */
export function resolveLifecycleLimits(context: LifecycleLimitContext, source?: LifecycleLimitSource): Promise<LifecycleLimitObservation> {
  return context.client instanceof InvocationLifecycleClient
    ? context.client.observeLimits(context, source)
    : resolveLifecycleLimitsFresh(context, source);
}

async function resolveLifecycleLimitsFresh(context: LifecycleLimitContext, source?: LifecycleLimitSource): Promise<LifecycleLimitObservation> {
  let configuration: LifecycleLimits;
  const policyContext = typeof source === "function" && context.client instanceof InvocationLifecycleClient ? { ...context, client: context.client.source } : context;
  try { configuration = source === undefined ? {} : typeof source === "function" ? await source(policyContext) : source; }
  catch (failure) {
    if (failure instanceof Error && failure.name === "AbortError") throw failure;
    throw new LifecyclePlanningError("LIMIT_SOURCE_FAILED", `Supplied execution policy could not be resolved: ${lifecycleFailureReason(failure)}`);
  }
  if (configuration === null || typeof configuration !== "object" || Array.isArray(configuration)) throw new LifecyclePlanningError("INVALID_LIMITS", "Supplied execution policy must be an object");
  const suppliedConfiguration = configuration;
  configuration = Object.freeze({ ...configuration });
  const configurationKeys = Object.keys(configuration) as (keyof LifecycleLimits)[];
  const assertCurrent = () => {
    if (Object.keys(suppliedConfiguration).length !== configurationKeys.length || configurationKeys.some((key) => suppliedConfiguration[key] !== configuration[key])) {
      throw new LifecyclePlanningError("LIMIT_CONTEXT_MISMATCH", "Supplied execution policy changed after its pinned observation");
    }
  };
  const headroomBps = configuration.headroomBps === undefined ? 1500 : configuration.headroomBps;
  if (!Number.isSafeInteger(headroomBps) || headroomBps < 0 || headroomBps > 10000) throw new LifecyclePlanningError("INVALID_LIMITS", "Headroom must be between zero and 10000 basis points");
  for (const limit of [context.block.gasLimit, configuration.chainGasLimit, configuration.rpcGasLimit, configuration.accountGasLimit, configuration.maxSimulationGas]) {
    if (limit !== undefined && (typeof limit !== "bigint" || limit <= 0n || limit > maxUint64)) throw new LifecyclePlanningError("INVALID_LIMITS", "Gas caps must be positive exact uint64 bigint values");
  }
  if (configuration.maxCalldataBytes !== undefined && (!Number.isSafeInteger(configuration.maxCalldataBytes) || configuration.maxCalldataBytes <= 0)) throw new LifecyclePlanningError("INVALID_LIMITS", "Calldata cap must be a positive byte count");
  if (configuration.estimateDataFee !== undefined && typeof configuration.estimateDataFee !== "function") throw new LifecyclePlanningError("INVALID_LIMITS", "External data-fee estimator must be a function");
  if (configuration.chainId !== undefined && (typeof configuration.chainId !== "bigint" || configuration.chainId !== context.chainId) ||
    configuration.observedBlockNumber !== undefined && (typeof configuration.observedBlockNumber !== "bigint" || configuration.observedBlockNumber !== context.block.number) ||
    configuration.observedBlockHash !== undefined && (typeof configuration.observedBlockHash !== "string" || !/^0x[\da-fA-F]{64}$/.test(configuration.observedBlockHash) || configuration.observedBlockHash.toLowerCase() !== context.block.hash.toLowerCase()) ||
    configuration.account !== undefined && (typeof configuration.account !== "string" || !isAddress(configuration.account) || configuration.account.toLowerCase() !== context.account.toLowerCase()) ||
    configuration.orchestrator !== undefined && (typeof configuration.orchestrator !== "string" || !isAddress(configuration.orchestrator) || configuration.orchestrator.toLowerCase() !== context.orchestrator.toLowerCase())) {
    throw new LifecyclePlanningError("LIMIT_CONTEXT_MISMATCH", "Supplied execution policy provenance differs from the canonical chain/account/core/block context");
  }
  const protocol = context.chainId === 4663n ? "nitro" : "evm";
  let arbOSVersion: bigint | undefined; let maxTxComputeGas: bigint | undefined; let maxBlockComputeGas: bigint | undefined;
  if (protocol === "nitro") {
    try {
      const [rawVersion, txComputeGas, blockComputeGas] = await Promise.all([
        readNitroScalar(context, nitroArbSys, nitroArbSysAbi, "arbOSVersion"),
        readNitroScalar(context, nitroGasInfo, nitroGasInfoAbi, "getMaxTxGasLimit"),
        readNitroScalar(context, nitroGasInfo, nitroGasInfoAbi, "getMaxBlockGasLimit"),
      ]);
      // ArbSys alone adds 55 to the logical Nitro ArbOS version.
      if (typeof rawVersion !== "bigint" || rawVersion < 105n) throw new Error("ArbOS version 50 or newer is required (ArbSys raw version >= 105)");
      arbOSVersion = rawVersion - 55n;
      maxTxComputeGas = txComputeGas;
      maxBlockComputeGas = blockComputeGas;
      if ([maxTxComputeGas, maxBlockComputeGas].some((limit) => typeof limit !== "bigint" || limit <= 0n || limit > maxUint64)) throw new Error("Nitro compute getters must be positive uint64 values");
    } catch (failure) {
      if (failure instanceof Error && failure.name === "AbortError") throw failure;
      throw new LifecyclePlanningError("NITRO_LIMITS_UNAVAILABLE", `Pinned Nitro compute limits could not be established: ${lifecycleFailureReason(failure)}; header gasLimit is not a fallback`);
    }
    if (configuration.estimateDataFee !== undefined) throw new LifecyclePlanningError("INVALID_LIMITS", "Nitro poster fees are already included in gas; an external data-fee estimator would double-charge them");
  }
  const envelopeCaps = [configuration.chainGasLimit, configuration.rpcGasLimit, configuration.accountGasLimit].filter((limit): limit is bigint => limit !== undefined);
  if (protocol === "evm") envelopeCaps.push(context.block.gasLimit);
  const transactionGasCeiling = envelopeCaps.length === 0 ? undefined : envelopeCaps.reduce((minimum, limit) => limit < minimum ? limit : minimum);
  const executionGasCeiling = maxTxComputeGas !== undefined && maxBlockComputeGas !== undefined
    ? (maxTxComputeGas < maxBlockComputeGas ? maxTxComputeGas : maxBlockComputeGas)
    : transactionGasCeiling ?? context.block.gasLimit;
  const unknownExecutionConstraints = [
    ...(protocol === "evm" && configuration.chainGasLimit === undefined ? ["Independent chain per-transaction execution cap is unknown; proof is bounded by the pinned header and validated backend"] : []),
    ...(configuration.rpcGasLimit === undefined ? ["RPC transaction gas-envelope cap is unknown"] : []),
    ...(configuration.accountGasLimit === undefined ? ["Current account/wallet transaction gas-envelope cap is unknown"] : []),
    ...(configuration.maxCalldataBytes === undefined ? ["Applicable chain/account/RPC calldata byte cap is unknown"] : []),
    ...(configuration.maxSimulationGas === undefined ? ["RPC aggregate simulation gas cap is unknown"] : []),
  ];
  assertCurrent();
  return {
    configuration, assertCurrent,
    limits: Object.freeze({
      protocol, executionGasCeiling, transactionGasCeiling, arbOSVersion, maxTxComputeGas, maxBlockComputeGas, headroomBps,
      maxCalldataBytes: configuration.maxCalldataBytes, maxSimulationGas: configuration.maxSimulationGas,
      blockGasLimit: context.block.gasLimit, chainGasLimit: configuration.chainGasLimit,
      rpcGasLimit: configuration.rpcGasLimit, accountGasLimit: configuration.accountGasLimit,
      unknownExecutionConstraints: Object.freeze(unknownExecutionConstraints),
      unknownConstraints: Object.freeze([...unknownExecutionConstraints, ...(protocol === "evm" && configuration.estimateDataFee === undefined ? ["External chain-specific data fee is unavailable"] : [])]),
    }),
  };
}
